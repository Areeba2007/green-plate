"""Read the CSV files with Python and print what has been stored. Run: python view_data.py"""
import csv
import os

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')

for name in ('foods', 'bmi', 'water', 'newsletter', 'messages', 'questions'):
    file = os.path.join(DATA, name + '.csv')
    if not os.path.exists(file):
        print(f'{name}.csv not found yet. Run python app.py once to create it.\n')
        continue
    with open(file, newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    print(f'== {name}.csv ({len(rows)} rows) ==')
    for row in rows:
        print(' | '.join(f'{k}: {v}' for k, v in row.items()))
    print()
