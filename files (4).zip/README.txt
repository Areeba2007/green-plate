GreenPlate with a Python + CSV backend (VS Code)
1. pip install -r requirements.txt
2. python app.py            then open http://127.0.0.1:5000
3. Use the site: BMI, water tracker, newsletter, Contact and Ask an Expert all save to the data/ folder:
     data/bmi.csv  data/water.csv  data/newsletter.csv  data/messages.csv  data/questions.csv
     data/foods.csv (the food list the Nutrition search reads)   data/voice/ (recorded voice notes)
4. Read the stored data with Python:  python view_data.py   (or open the CSV files in Excel)
Files: app.py (backend), index.html (website), view_data.py (reads the CSVs), requirements.txt
